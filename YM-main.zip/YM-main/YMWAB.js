{
	"version": "10.0",
	"download": "https://ymmods-official.blogspot.com/2021/04/ymwab.html",
	"update": [
		{
			"languaje": "en",
			"changelog": "https://raw.githubusercontent.com/JesusMuentes/YM/main/changelog-B-en.html"
		},
		{
			"languaje": "es",
			"changelog": "https://raw.githubusercontent.com/JesusMuentes/YM/main/changelog-B-es.html"
		}
	]
}