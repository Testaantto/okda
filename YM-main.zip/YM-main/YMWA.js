{
	"version": "19.1",
	"download": "https://ymmods-official.blogspot.com/2021/04/ymwa.html",
	"update": [
		{
			"languaje": "en",
			"changelog": "https://raw.githubusercontent.com/JesusMuentes/YM/main/changelog-en.html"
		},
		{
			"languaje": "es",
			"changelog": "https://raw.githubusercontent.com/JesusMuentes/YM/main/changelog-es.html"
		},
		{
			"languaje": "pt",
			"changelog": "https://raw.githubusercontent.com/JesusMuentes/YM/main/changelog-pt.html"
		}
	]
}
